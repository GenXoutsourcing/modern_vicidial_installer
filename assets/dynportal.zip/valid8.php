<?php
# valid8.php - ViciBox dynamic firewall validation portal
#
# Copyright (C) 2018  James Pearson <jamesp@vicidial.com>    LICENSE: AGPLv2
# 
# See the CHANGES file in the ./inc directory for the change log
#

// Required includes
require_once 'inc/defaults.inc.php'; // Edit this for astguiclient.conf location
require_once 'inc/dbconnect.inc.php';
require_once 'inc/functions.inc.php';

// See if we are redirected from elsewhere and are secure
$loginstate=0; // 0 = no attempt, 1 = failed, 2 = success
if (chkgetpost("login")) { $loginstate=getpostvar("login"); }

// If we are submitted, then do stuff, otherwise output HTML
if (chkgetpost('submit')) {
	$remoteip=$_SERVER['REMOTE_ADDR'];
	debugoutput("   IP $remoteip validation check submit",2);
	// Get our login and password and set our vars
	$login = getpostvar("$PORTAL_useridvar");
	$pass = getpostvar("$PORTAL_passwdvar");
	$usergroup = '';
	debugoutput("Login: $login",2);
	debugoutput("Pass: $pass",2);
	$today = date("Y-m-d H:i:s");
	
	// Force a delay if configured to reduce the attractiveness of brute-forcing a login
	if ($PORTAL_incurdelay>0) {
		sleep($PORTAL_incurdelay);
	}
	
	if (validate_pw($login,$pass)) {
		#logaction($login,'LOGIN',$_SERVER['REMOTE_ADDR']);
		$loginstate=2;
		logvalidip($login, $remoteip, $usergroup);
		debugoutput("Login Successful $today - User $login, IP $remoteip");
		
		# Insert the IP address into the local IPSet when authenticated
		if ($PORTAL_submitlocal == 1) {
			debugoutput("  Adding $remoteip to dynamiclist IPSET",2);
			# Must setuid on /usr/sbin/ipset for this to work
			$SHELL_cmd='/usr/sbin/ipset add dynamiclist ' . $remoteip . ' 2>&1';
			shell_exec($SHELL_cmd);
		}
		
		} else {
			#logaction($login,'FAILEDLOGIN',$_SERVER['REMOTE_ADDR']);
			$loginstate=1;
			debugoutput("Login Unsuccessful $today - User $login, IP $remoteip");
	}
} 

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Pragma" content="no-cache">
  <title>Secure Access</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/w3.css">
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Roboto', sans-serif;
      color: #333;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      padding: 20px;
      overflow: hidden;
    }

    video#bg-video {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      z-index: -1;
    }

    .container {
      background: rgba(255, 255, 255, 1);
      border-radius: 12px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      max-width: 400px;
      width: 100%;
      padding: 30px;
    }

    .header {
      text-align: center;
      margin-bottom: 20px;
    }

    .header h4 {
      font-size: 1.5rem;
      color: #555;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    label {
      font-weight: 500;
      font-size: 0.9rem;
    }

    input[type="text"],
    input[type="password"] {
      width: 100%;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 8px;
      font-size: 0.9rem;
    }

    input[type="submit"] {
      padding: 12px;
      background-color: #0077b6;
      color: #fff;
      font-size: 1rem;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    input[type="submit"]:hover {
      background-color: #005f87;
    }

    .footer {
      text-align: center;
      margin-top: 20px;
      font-size: 0.8rem;
      color: #777;
    }

    .message {
      text-align: center;
      margin-bottom: 20px;
      font-size: 1rem;
      font-weight: bold;
    }

    .message.error {
      color: red;
    }

    .message.success {
      color: green;
    }

    .redirect {
      margin-top: 30px;
      text-align: center;
      font-size: 1rem;
    }

    @media (max-width: 480px) {
      .container {
        padding: 20px;
      }
    }
  </style>
</head>
<body>
  <video id="bg-video" autoplay muted loop>
    <source src="../images/(Insert Video File).mp4" type="video/mp4">
    Your browser does not support the video tag.
  </video>

  <div class="container">
    <?php
    // Set dynamic feedback based on login state
    if ($loginstate == 1) {
        echo '<div class="message error">Login Incorrect!</div>';
    } elseif ($loginstate == 2) {
        echo '<div class="message success">Login Validated for IP ' . $remoteip . '</div>';
    } elseif (!checksecure()) {
        echo '<div class="message error">Connection not using SSL!</div>';
    }
    ?>

    <div class="header">
      <h4><b>Secure Access</b></h4>
    </div>
    <form action="valid8.php" method="post">
      <label for="<?php echo $PORTAL_useridvar; ?>">User ID</label>
      <input type="text" id="<?php echo $PORTAL_useridvar; ?>" name="<?php echo $PORTAL_useridvar; ?>" value="" required>

      <label for="<?php echo $PORTAL_passwdvar; ?>">Password</label>
      <input type="hidden" id="password" name="password">
      <input type="password" id="<?php echo $PORTAL_passwdvar; ?>" name="<?php echo $PORTAL_passwdvar; ?>" value="" required>

      <input type="submit" value="Submit" name="submit">
    </form>

    <?php
    if ($loginstate == 2 && $PORTAL_redirecturl != 'X') {
        echo '<div class="redirect">Redirecting to <a href="' . $PORTAL_redirecturl . '">Login Page</a> in <span id="countdown">' . $PORTAL_redirectsecs . '</span> seconds.<br>Please bookmark the login page for easier access in the future.</div>';
        echo '<script>
        var timeInSecs = ' . $PORTAL_redirectsecs . ' - 1;
        var ticker = setInterval(function() {
          if (timeInSecs > 0) {
            timeInSecs--;
            document.getElementById("countdown").innerText = timeInSecs;
          } else {
            clearInterval(ticker);
            window.location.replace("' . $PORTAL_redirecturl . '");
          }
        }, 1000);
        </script>';
    }
    ?>

    <div class="footer">
      <p>&copy; <?php echo date('Y'); ?> CyburDial - All rights reserved.</p>
    </div>
  </div>
</body>
</html>


