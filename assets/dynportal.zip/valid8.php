<?php
# valid8.php - ViciBox dynamic firewall validation portal
#
# Copyright (C) 2018  James Pearson <jamesp@vicidial.com>    LICENSE: AGPLv2
#
# See the CHANGES file in the ./inc directory for the change log
#
# GenX Contact Center theme — matches the GenX UI sign-in look.
#

// Required includes
require_once 'inc/defaults.inc.php'; // Edit this for astguiclient.conf location
require_once 'inc/dbconnect.inc.php';
require_once 'inc/functions.inc.php';

// See if we are redirected from elsewhere and are secure
$loginstate=0; // 0 = no attempt, 1 = failed, 2 = success
if (chkgetpost("login")) { $loginstate=getpostvar("login"); }

// If we are submitted, then do stuff, otherwise output HTML
if (chkgetpost('submit')) {
	$remoteip=$_SERVER['REMOTE_ADDR'];
	debugoutput("   IP $remoteip validation check submit",2);
	// Get our login and password and set our vars
	$login = getpostvar("$PORTAL_useridvar");
	$pass = getpostvar("$PORTAL_passwdvar");
	$usergroup = '';
	debugoutput("Login: $login",2);
	debugoutput("Pass: $pass",2);
	$today = date("Y-m-d H:i:s");

	// Force a delay if configured to reduce the attractiveness of brute-forcing a login
	if ($PORTAL_incurdelay>0) {
		sleep($PORTAL_incurdelay);
	}

	if (validate_pw($login,$pass)) {
		#logaction($login,'LOGIN',$_SERVER['REMOTE_ADDR']);
		$loginstate=2;
		logvalidip($login, $remoteip, $usergroup);
		debugoutput("Login Successful $today - User $login, IP $remoteip");

		# Insert the IP address into the local IPSet when authenticated
		if ($PORTAL_submitlocal == 1) {
			debugoutput("  Adding $remoteip to dynamiclist IPSET",2);
			# Must setuid on /usr/sbin/ipset for this to work
			$SHELL_cmd='/usr/sbin/ipset add dynamiclist ' . $remoteip . ' 2>&1';
			shell_exec($SHELL_cmd);
		}

		} else {
			#logaction($login,'FAILEDLOGIN',$_SERVER['REMOTE_ADDR']);
			$loginstate=1;
			debugoutput("Login Unsuccessful $today - User $login, IP $remoteip");
	}
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Pragma" content="no-cache">
  <title>GenX Secure Access</title>
  <style>
    :root {
      --page: #050812;
      --surface: rgba(8, 17, 31, 0.94);
      --line: rgba(0, 217, 255, 0.34);
      --line-soft: rgba(117, 186, 255, 0.18);
      --text: #e8f7ff;
      --muted: #8aa7bb;
      --blue: #00d9ff;
      --blue-strong: #2d7dff;
      --green: #73fbd3;
      --danger: #ff7c9b;
      --shadow: rgba(0, 217, 255, 0.18);
    }

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    html { min-height: 100%; }

    body {
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 24px;
      color: var(--text);
      background:
        linear-gradient(rgba(0, 217, 255, 0.035) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0, 217, 255, 0.035) 1px, transparent 1px),
        linear-gradient(180deg, #07182a 0%, #050812 48%, #03050a 100%);
      background-size: 34px 34px, 34px 34px, 100% 100%;
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      -webkit-font-smoothing: antialiased;
    }

    .login-panel {
      width: min(440px, 100%);
      padding: 28px;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: var(--surface);
      box-shadow: 0 0 0 1px rgba(0, 217, 255, 0.08), 0 24px 80px rgba(0, 0, 0, 0.38), 0 0 44px var(--shadow);
    }

    .brand-lock {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 6px;
    }

    .brand-mark {
      display: grid;
      width: 44px;
      height: 44px;
      flex: 0 0 44px;
      place-items: center;
      border-radius: 8px;
      border: 1px solid rgba(115, 251, 211, 0.36);
      background: linear-gradient(135deg, #0a1a2e, #05283d);
      color: #f8feff;
      font-weight: 800;
      font-size: 1rem;
      box-shadow: inset 0 0 18px rgba(0, 217, 255, 0.16), 0 0 22px rgba(0, 217, 255, 0.28);
    }

    .eyebrow {
      margin-bottom: 4px;
      color: var(--blue);
      font-size: 0.76rem;
      font-weight: 760;
      text-transform: uppercase;
      letter-spacing: 0.02em;
    }

    h1 {
      font-size: 1.35rem;
      line-height: 1.1;
      color: var(--text);
    }

    .message {
      margin-top: 18px;
      padding: 10px 14px;
      border-radius: 8px;
      font-size: 0.9rem;
      font-weight: 700;
      border: 1px solid transparent;
    }

    .message.error {
      color: var(--danger);
      border-color: rgba(255, 124, 155, 0.4);
      background: rgba(255, 124, 155, 0.08);
    }

    .message.success {
      color: var(--green);
      border-color: rgba(115, 251, 211, 0.4);
      background: rgba(115, 251, 211, 0.08);
    }

    form {
      display: grid;
      gap: 14px;
      margin-top: 26px;
    }

    label {
      color: var(--text);
      font-weight: 700;
      font-size: 0.9rem;
    }

    .input-row {
      display: flex;
      align-items: center;
      gap: 10px;
      height: 48px;
      padding: 0 14px;
      border: 1px solid var(--line-soft);
      border-radius: 8px;
      background: rgba(3, 9, 18, 0.72);
    }

    .input-row:focus-within {
      border-color: var(--blue);
      box-shadow: 0 0 0 3px rgba(0, 217, 255, 0.16), 0 0 24px rgba(0, 217, 255, 0.22);
    }

    .input-row input {
      width: 100%;
      min-width: 0;
      border: 0;
      outline: 0;
      background: transparent;
      color: var(--text);
      font-size: 0.95rem;
    }

    /* Keep Chrome autofill from painting the inputs white. */
    .input-row input:-webkit-autofill,
    .input-row input:-webkit-autofill:focus {
      -webkit-text-fill-color: var(--text);
      -webkit-box-shadow: 0 0 0 1000px #071528 inset;
      box-shadow: 0 0 0 1000px #071528 inset;
      caret-color: var(--text);
    }

    .field-icon {
      flex: 0 0 auto;
      color: var(--blue);
      opacity: 0.85;
    }

    input[type="submit"] {
      margin-top: 4px;
      min-height: 46px;
      border: 0;
      border-radius: 8px;
      background: linear-gradient(135deg, var(--blue), var(--blue-strong));
      color: #03101a;
      font-size: 1rem;
      font-weight: 780;
      cursor: pointer;
      box-shadow: 0 0 24px rgba(0, 217, 255, 0.34);
      transition: filter 0.2s ease;
    }

    input[type="submit"]:hover { filter: brightness(1.08); }

    .redirect {
      margin-top: 22px;
      text-align: center;
      font-size: 0.9rem;
      color: var(--muted);
      line-height: 1.5;
    }

    .redirect a {
      color: var(--blue);
      font-weight: 700;
      text-decoration: none;
    }

    .redirect a:hover { text-decoration: underline; }

    #countdown { color: var(--text); font-weight: 800; }

    .footer {
      margin-top: 24px;
      text-align: center;
      font-size: 0.72rem;
      letter-spacing: 0.08em;
      color: var(--muted);
    }

    @media (max-width: 480px) {
      .login-panel { padding: 22px; }
    }
  </style>
</head>
<body>
  <div class="login-panel">
    <div class="brand-lock">
      <div class="brand-mark">GX</div>
      <div>
        <p class="eyebrow">GenX Contact Center</p>
        <h1>Secure Access</h1>
      </div>
    </div>

    <?php
    // Set dynamic feedback based on login state
    if ($loginstate == 1) {
        echo '<div class="message error">Login Incorrect!</div>';
    } elseif ($loginstate == 2) {
        echo '<div class="message success">Login validated for IP ' . htmlspecialchars($remoteip, ENT_QUOTES) . '</div>';
    } elseif (!checksecure()) {
        echo '<div class="message error">Connection not using SSL!</div>';
    }
    ?>

    <form action="valid8.php" method="post">
      <label for="<?php echo $PORTAL_useridvar; ?>">User ID</label>
      <div class="input-row">
        <svg class="field-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        <input type="text" id="<?php echo $PORTAL_useridvar; ?>" name="<?php echo $PORTAL_useridvar; ?>" value="" autocomplete="username" required autofocus>
      </div>

      <label for="<?php echo $PORTAL_passwdvar; ?>">Password</label>
      <input type="hidden" id="password" name="password">
      <div class="input-row">
        <svg class="field-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        <input type="password" id="<?php echo $PORTAL_passwdvar; ?>" name="<?php echo $PORTAL_passwdvar; ?>" value="" autocomplete="current-password" required>
      </div>

      <input type="submit" value="Validate Access" name="submit">
    </form>

    <?php
    if ($loginstate == 2 && $PORTAL_redirecturl != 'X') {
        $safe_redirect = htmlspecialchars($PORTAL_redirecturl, ENT_QUOTES);
        echo '<div class="redirect">Redirecting to <a href="' . $safe_redirect . '">the login page</a> in <span id="countdown">' . intval($PORTAL_redirectsecs) . '</span> seconds.<br>Please bookmark the login page for easier access in the future.</div>';
        echo '<script>
        var timeInSecs = ' . intval($PORTAL_redirectsecs) . ' - 1;
        var ticker = setInterval(function() {
          if (timeInSecs > 0) {
            timeInSecs--;
            document.getElementById("countdown").innerText = timeInSecs;
          } else {
            clearInterval(ticker);
            window.location.replace(' . json_encode($PORTAL_redirecturl) . ');
          }
        }, 1000);
        </script>';
    }
    ?>

    <div class="footer">
      &copy; <?php echo date('Y'); ?> GenX Contact Center &mdash; All rights reserved.
    </div>
  </div>
</body>
</html>
